from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/velas")
def get_velas():
    velas_mock = [1.42, 2.11, 3.87, 7.12, 1.03, 11.56, 2.75, 5.44, 9.88, 2.21,
                  1.01, 12.45, 3.33, 2.02, 1.98, 15.76, 6.32, 4.44, 1.22, 18.92]
    return {"velas": velas_mock}
